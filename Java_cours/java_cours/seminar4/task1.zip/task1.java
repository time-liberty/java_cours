public class task1 {

}
